import{default as t}from"../components/pages/about/_page.svelte-9eeebaed.js";export{t as component};
