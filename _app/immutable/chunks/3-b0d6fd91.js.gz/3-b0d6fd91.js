import{default as t}from"../components/pages/about/_page.svelte-a3663118.js";export{t as component};
