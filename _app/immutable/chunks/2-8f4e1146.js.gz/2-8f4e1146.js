import{default as t}from"../components/pages/_page.svelte-1fa68113.js";export{t as component};
