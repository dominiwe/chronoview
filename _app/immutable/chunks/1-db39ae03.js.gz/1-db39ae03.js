import{default as t}from"../components/error.svelte-859a46fa.js";export{t as component};
