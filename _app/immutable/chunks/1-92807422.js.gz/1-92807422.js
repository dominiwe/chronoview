import{default as t}from"../components/error.svelte-c356fef3.js";export{t as component};
