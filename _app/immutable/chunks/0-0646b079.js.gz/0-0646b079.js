import{_ as r}from"./_layout-7651724a.js";import{default as t}from"../components/pages/_layout.svelte-5995d0bf.js";export{t as component,r as universal};
