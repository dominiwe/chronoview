import{default as t}from"../components/pages/about/_page.svelte-74057407.js";export{t as component};
