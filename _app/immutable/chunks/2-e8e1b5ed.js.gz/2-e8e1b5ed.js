import{default as t}from"../components/pages/_page.svelte-35baea37.js";export{t as component};
