const r=!0,t=!0,e="ignore",s=Object.freeze(Object.defineProperty({__proto__:null,prerender:!0,ssr:!0,trailingSlash:e},Symbol.toStringTag,{value:"Module"}));export{s as _,r as p,t as s,e as t};
