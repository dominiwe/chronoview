const r=!0,s=!1,e="ignore",t=Object.freeze(Object.defineProperty({__proto__:null,prerender:!0,ssr:!1,trailingSlash:e},Symbol.toStringTag,{value:"Module"}));export{t as _,r as p,s,e as t};
