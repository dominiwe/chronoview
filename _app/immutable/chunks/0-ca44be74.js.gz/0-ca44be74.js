import{_ as r}from"./_layout-025914ab.js";import{default as t}from"../components/pages/_layout.svelte-5995d0bf.js";export{t as component,r as universal};
