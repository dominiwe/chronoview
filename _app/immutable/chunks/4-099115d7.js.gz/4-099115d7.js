import{default as t}from"../components/pages/config/_page.svelte-2480781e.js";export{t as component};
