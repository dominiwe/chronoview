import{default as t}from"../components/pages/_page.svelte-748f1fda.js";export{t as component};
