import{default as t}from"../components/pages/config/_page.svelte-007148f7.js";export{t as component};
