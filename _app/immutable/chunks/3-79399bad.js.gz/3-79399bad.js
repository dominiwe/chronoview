import{default as t}from"../components/pages/about/_page.svelte-b4a80aa1.js";export{t as component};
