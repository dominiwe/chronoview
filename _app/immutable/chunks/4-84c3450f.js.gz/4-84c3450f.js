import{default as t}from"../components/pages/config/_page.svelte-47d88ca7.js";export{t as component};
