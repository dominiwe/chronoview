import{_ as r}from"./_layout-025914ab.js";import{default as t}from"../components/pages/_layout.svelte-5484c48c.js";export{t as component,r as universal};
