import{default as t}from"../components/pages/_page.svelte-7b09eedf.js";export{t as component};
